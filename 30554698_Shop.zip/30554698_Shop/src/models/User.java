package models;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 30554698
 */
public class User 
{
    //Attributes
    private String username;
    private String password;
    private String firstName;
    private String lastName;
    
// Getters

public String getUsername()
{
    return username;
}

public String getPassword()
{
    return password;
}

public String getFirstName()
{
    return firstName;
}

public String getLastName()
{
    return lastName;
}


// Setters

public void setUsername(String username)
{
    this.username = username;
}

public void setPassword(String password)
{
    this.password = password;
}

public void setFirstName(String firstName)
{
    this.firstName = firstName;
}

public void setLastName(String lastName)
{
    this.lastName = lastName;
}

    public User()
    {
        username = "";
        password = "";
        firstName = "";
        lastName = "";
    }

    public User(String username, String password, String firstName, String lastName) {
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;
    }

}
