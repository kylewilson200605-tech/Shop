
package models;

import java.util.ArrayList;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.DriverManager;

/**
 *
 * @author jahood
 */
public class DBManager {

    private final String driver = "net.ucanaccess.jdbc.UcanaccessDriver";
    private final String connectionString = "jdbc:ucanaccess://Data\\ZooShopDB.accdb";

    public ArrayList<Animal> LoadAnimals()
    {
        ArrayList<Animal> allAnimals = new ArrayList<>();

        try
        {
            Class.forName(driver);
            Connection conn = DriverManager.getConnection(connectionString);
            Statement stat = conn.createStatement();
            ResultSet rs = stat.executeQuery("SELECT * FROM Animals");

            while(rs.next())
            {
                int animalId = rs.getInt("AnimalId");
                String name = rs.getString("AnimalName");
                char gender = rs.getString("Gender").charAt(0);
                String type = rs.getString("Type");
                int age = rs.getInt("Age");
                String waterType = rs.getString("WaterType");
                boolean canFly = rs.getBoolean("CanFly");
                boolean availability = rs.getBoolean("Availability");
                double cost = rs.getDouble("Cost");
                String animalCategory = rs.getString("AnimalCategory");

                if(animalCategory.equals("Bird"))
                {
                    Bird birdFromDB = new Bird(animalId, name, type, age, cost, availability, gender, canFly);
                    allAnimals.add(birdFromDB);
                }
                else
                {
                    Fish fishFromDB = new Fish(animalId, name, type, age, cost, availability, gender, waterType);
                    allAnimals.add(fishFromDB);
                }
            }

            rs.close();
            stat.close();
            conn.close();
        }
        catch(Exception ex)
        {
            System.out.println(ex.getMessage());
        }

        return allAnimals;
    }
}
